from itertools import count
from turtle import title
from django.db import models

# Create your models here.

class Poll(models.Model):
    #投票主題
    subject=models.CharField(max_length=200, verbose_name = '主題')
    #投票建立日期
    date_created=models.DateField(auto_now_add=True)
    
    def __str__(self):
       return str(self.subject)  
    #"點單"的id值為2

class Option(models.Model):
    #此處屬於哪一個投票
    poll_id=models.IntegerField()
    #選項文字sudo python3 manage.py runserver 0.0.0.0:80
    title= models.CharField(max_length=200, verbose_name='投票選項')
    #此選項被投票數
    count=models.IntegerField(default=0)

    def __str__(self):
        return str(self.poll_id) + ": " + self.title